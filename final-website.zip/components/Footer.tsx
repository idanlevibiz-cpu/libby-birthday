"use client";

import { useLanguage } from "@/lib/i18n";

export function Footer() {
    const { t } = useLanguage();

    return (
        <footer className="py-8 text-center bg-emerald-900/5 mt-auto">
            <a
                href="https://www.instagram.com/epica_eventsai"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] uppercase tracking-widest text-emerald-900/50 hover:text-gold-600 transition-colors"
            >
                {t.footer.developedBy}
            </a>
        </footer>
    );
}
