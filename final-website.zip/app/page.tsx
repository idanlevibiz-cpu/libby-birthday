"use client";

import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Envelope } from "@/components/Envelope";
import { motion, AnimatePresence } from "framer-motion";
import { Invitation } from "@/components/Invitation";

export default function Home() {
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);

  return (
    <main className="min-h-screen bg-cream-50 overflow-x-hidden flex flex-col">
      <Header />

      <AnimatePresence>
        {!isEnvelopeOpen && (
          <motion.div
            key="envelope"
            exit={{ opacity: 0, transition: { duration: 1 } }}
            className="fixed inset-0 z-40"
          >
            <Envelope onOpen={() => setIsEnvelopeOpen(true)} />
          </motion.div>
        )}
      </AnimatePresence>

      {isEnvelopeOpen && (
        <motion.div
          key="invitation"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="flex-1 w-full"
        >
          {/* Placeholder for Invitation Component */}
          <Invitation />
          <Footer />
        </motion.div>
      )}
    </main>
  );
}
