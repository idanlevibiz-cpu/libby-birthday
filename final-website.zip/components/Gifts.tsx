"use client";

import { useLanguage } from "@/lib/i18n";
import { Gift } from "lucide-react";

export function Gifts() {
    const { t } = useLanguage();

    return (
        <div id="gifts-section" className="w-full">
            <div className="bg-white/10 backdrop-blur-xl p-8 md:p-10 rounded-[40px] shadow-[0_8px_32px_0_rgba(0,0,0,0.36)] border border-white/20 space-y-10 group hover:bg-white/15 transition-colors duration-500">

                <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-gold-400/20 rounded-full animate-bounce delay-700">
                        <Gift className="w-8 h-8 text-gold-400" />
                    </div>
                    <h2 className="font-serif text-4xl text-center text-white drop-shadow-sm">{t.gifts.title}</h2>
                </div>

                {/* Card 1: Amazon */}
                <div className="text-center space-y-4">
                    <h3 className="font-serif text-2xl text-gold-200">{t.gifts.card1Title}</h3>
                    <p className="text-white/80 text-sm max-w-sm mx-auto">{t.gifts.card1Desc}</p>
                    <a
                        href="https://www.amazon.com/registries/gl/guest-view/3L2JI50Z6ET8E"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full py-4 mt-2 bg-gradient-to-r from-emerald-600 to-emerald-800 text-white rounded-2xl font-bold hover:shadow-lg hover:scale-[1.02] transition-all border border-emerald-400/30"
                    >
                        Amazon Wishlist
                    </a>
                </div>

                <div className="w-24 h-[1px] bg-white/10 mx-auto" />

                {/* Card 2: Future Fund */}
                <div className="text-center space-y-4">
                    <h3 className="font-serif text-2xl text-gold-200">{t.gifts.card2Title}</h3>
                    <p className="text-white/80 text-sm max-w-sm mx-auto">{t.gifts.card2Desc}</p>

                    <div className="flex flex-col gap-3 pt-2">
                        <a
                            href="https://www.athmovil.com/pay/noam2026"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full py-4 bg-orange-600 hover:bg-orange-500 text-white rounded-2xl font-bold transition-all shadow-md"
                        >
                            ATH Móvil
                        </a>
                        <a
                            href="https://www.paypal.me/epicevents/noam"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full py-4 bg-[#0070BA] hover:bg-[#005ea6] text-white rounded-2xl font-bold transition-all shadow-md"
                        >
                            PayPal
                        </a>
                    </div>
                </div>

            </div>
        </div>
    );
}
