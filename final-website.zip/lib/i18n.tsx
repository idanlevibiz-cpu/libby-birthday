"use client";

import React, { createContext, useContext, useState, useEffect } from "react";

type Language = "en" | "es";

type Translations = {
    header: {
        brand: string;
    };
    footer: {
        developedBy: string;
    };
    landing: {
        cta: string;
    };
    eventInfo: {
        title: string;
        date: string;
        time: string;
        location: string;
        welcomeMsg: string;
    };
    rsvp: {
        title: string;
        fullName: string;
        attendance: string;
        joyful: string;
        regretful: string;
        guests: string;
        dietary: string;
        declineMessage: string;
        submit: string;
        success: string;
        error: string;
    };
    gifts: {
        title: string;
        card1Title: string;
        card1Desc: string;
        card2Title: string;
        card2Desc: string;
    };
    gallery: {
        title: string;
        upload: string;
    };
};

const translations: Record<Language, Translations> = {
    en: {
        header: {
            brand: "EPIC EVENT",
        },
        footer: {
            developedBy: "Developed by Epic Event",
        },
        landing: {
            cta: "Open Envelope",
        },
        eventInfo: {
            title: "Noam's 2nd Birthday Kick-off",
            date: "Monday, July 20, 2026",
            time: "1:00 PM (Match Start)",
            location: "52 Calle del Cristo,\nOld San Juan, PR 00901",
            welcomeMsg: "Two years of goals, giggles, and endless joy! \nJoin us on the field as we celebrate our MVP, Noam.\nYour presence is the best trophy we could ask for!",
        },
        rsvp: {
            title: "Join the Team (RSVP)",
            fullName: "Player Name",
            attendance: "Will you stay for the match?",
            joyful: "I'm in the Starting Lineup! (Accept)",
            regretful: "I'm on the Bench (Decline)",
            guests: "Number of Teammates",
            dietary: "Fuel/Dietary Needs",
            declineMessage: "We'll miss you on the field! Check out the gift zone below.",
            submit: "Confirm Registration",
            success: "Goal! You're registered for the party.",
            error: "Foul! Something went wrong. Try again.",
        },
        gifts: {
            title: "Trophy Room & Wishes",
            card1Title: "Equipment & Gear",
            card1Desc: "Toys and books to help Noam train for the big leagues.",
            card2Title: "Future League Fund",
            card2Desc: "Help us build Noam's stadium for the future.",
        },
        gallery: {
            title: "Match Highlights",
            upload: "Upload Replay",
        },
    },
    es: {
        header: {
            brand: "EPIC EVENT",
        },
        footer: {
            developedBy: "Developed by Epic Event",
        },
        landing: {
            cta: "Entrar al Campo",
        },
        eventInfo: {
            title: "¡El Gran Partido de Noam!",
            date: "Lunes, 20 de Julio, 2026",
            time: "1:00 PM (Inicio de Partido)",
            location: "52 Calle del Cristo,\nOld San Juan, PR 00901",
            welcomeMsg: "¡Dos años de goles, risas y alegría infinita! \nÚnete a nosotros en la cancha para celebrar a nuestro MVP, Noam.\n¡Tu presencia es el mejor trofeo!",
        },
        rsvp: {
            title: "Únete al Equipo (RSVP)",
            fullName: "Nombre del Jugador",
            attendance: "¿Jugarás el partido?",
            joyful: "¡Soy Titular! (Acepto)",
            regretful: "Estoy en la Banca (No Asistiré)",
            guests: "Número de Compañeros",
            dietary: "Necesidades Especiales",
            declineMessage: "¡Te extrañaremos en la cancha! Mira la zona de regalos abajo.",
            submit: "Confirmar Fichaje",
            success: "¡Gol! Estás registrado para la fiesta.",
            error: "¡Falta! Algo salió mal. Intenta de nuevo.",
        },
        gifts: {
            title: "Trofeos y Deseos",
            card1Title: "Equipamiento",
            card1Desc: "Juguetes y libros para el entrenamiento de Noam.",
            card2Title: "Fondo para el Futuro",
            card2Desc: "Ayúdanos a construir el estadio del futuro para Noam.",
        },
        gallery: {
            title: "Mejores Jugadas",
            upload: "Subir Foto",
        },
    },
};

interface LanguageContextType {
    lang: Language;
    setLang: (lang: Language) => void;
    t: Translations;
    toggleLang: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
    const [lang, setLang] = useState<Language>("en");

    // Persist language selection
    useEffect(() => {
        const savedLang = localStorage.getItem("epica-lang") as Language;
        if (savedLang) {
            setLang(savedLang);
        }
    }, []);

    const toggleLang = () => {
        const newLang = lang === "en" ? "es" : "en";
        setLang(newLang);
        localStorage.setItem("epica-lang", newLang);
    };

    return (
        <LanguageContext.Provider value={{ lang, setLang, t: translations[lang], toggleLang }}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLanguage() {
    const context = useContext(LanguageContext);
    if (context === undefined) {
        throw new Error("useLanguage must be used within a LanguageProvider");
    }
    return context;
}
