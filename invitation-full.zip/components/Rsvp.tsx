"use client";

import { useState } from "react";
import { useLanguage } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { Loader2, CheckCircle, Ticket } from "lucide-react";

export function Rsvp() {
    const { t } = useLanguage();
    const [formData, setFormData] = useState({
        name: "",
        attendance: "joyful", // 'joyful' or 'regretful'
        guests: 1,
        dietary: "",
    });
    const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus("submitting");

        try {
            const res = await fetch("/api/rsvp", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData),
            });
            const data = await res.json();

            if (data.success) {
                setStatus("success");
            } else {
                setStatus("error");
            }
        } catch (error) {
            console.error(error);
            setStatus("error");
        }
    };

    if (status === "success") {
        return (
            <div className="bg-emerald-900/80 backdrop-blur-xl rounded-[40px] p-8 shadow-2xl border border-emerald-500/30 text-center space-y-6 max-w-lg mx-auto animate-in zoom-in duration-500">
                <div className="flex justify-center">
                    <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center animate-bounce">
                        <CheckCircle className="w-10 h-10 text-emerald-400" />
                    </div>
                </div>
                <h3 className="font-serif text-3xl text-white drop-shadow-md">{t.rsvp.success}</h3>
                <p className="text-emerald-200">See you on the field!</p>
            </div>
        );
    }

    return (
        <div className="w-full">
            <div className="bg-white/10 backdrop-blur-xl p-8 md:p-10 rounded-[40px] shadow-[0_8px_32px_0_rgba(0,0,0,0.36)] border border-white/20 space-y-8">
                <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-gold-400/20 rounded-full">
                        <Ticket className="w-8 h-8 text-gold-400" />
                    </div>
                    <h2 className="font-serif text-4xl text-center text-white drop-shadow-sm">{t.rsvp.title}</h2>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Name */}
                    <div className="space-y-2 text-left">
                        <label className="block text-sm font-bold text-gold-200 uppercase tracking-widest pl-1">
                            {t.rsvp.fullName}
                        </label>
                        <input
                            type="text"
                            required
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            className="w-full px-6 py-4 rounded-2xl bg-black/20 border border-white/10 text-white placeholder-white/30 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-all"
                            placeholder="Lionel Messi..."
                        />
                    </div>

                    {/* Attendance Toggle */}
                    <div className="space-y-2 text-left">
                        <label className="block text-sm font-bold text-gold-200 uppercase tracking-widest pl-1">
                            {t.rsvp.attendance}
                        </label>
                        <div className="grid grid-cols-2 gap-3 p-1 bg-black/20 rounded-2xl border border-white/10">
                            <button
                                type="button"
                                onClick={() => setFormData({ ...formData, attendance: "joyful" })}
                                className={cn(
                                    "py-3 px-4 rounded-xl text-sm font-bold transition-all transform duration-200",
                                    formData.attendance === "joyful"
                                        ? "bg-emerald-600 text-white shadow-lg scale-[1.02]"
                                        : "text-white/60 hover:text-white"
                                )}
                            >
                                {t.rsvp.joyful}
                            </button>
                            <button
                                type="button"
                                onClick={() => setFormData({ ...formData, attendance: "regretful" })}
                                className={cn(
                                    "py-3 px-4 rounded-xl text-sm font-bold transition-all transform duration-200",
                                    formData.attendance === "regretful"
                                        ? "bg-red-500/80 text-white shadow-lg scale-[1.02]"
                                        : "text-white/60 hover:text-white"
                                )}
                            >
                                {t.rsvp.regretful}
                            </button>
                        </div>
                    </div>

                    {/* Conditional Fields */}
                    {formData.attendance === "joyful" ? (
                        <div className="space-y-6 animate-in slide-in-from-top-2 fade-in duration-300">
                            <div className="space-y-2 text-left">
                                <label className="block text-sm font-bold text-gold-200 uppercase tracking-widest pl-1">
                                    {t.rsvp.guests}
                                </label>
                                <div className="flex items-center gap-4 bg-black/20 p-2 rounded-2xl border border-white/10 w-fit">
                                    <button
                                        type="button"
                                        onClick={() => setFormData(p => ({ ...p, guests: Math.max(1, p.guests - 1) }))}
                                        className="w-10 h-10 rounded-xl bg-white/10 text-white flex items-center justify-center font-bold hover:bg-white/20 transition-colors"
                                    >
                                        -
                                    </button>
                                    <span className="text-xl font-bold text-white w-8 text-center">{formData.guests}</span>
                                    <button
                                        type="button"
                                        onClick={() => setFormData(p => ({ ...p, guests: Math.min(10, p.guests + 1) }))}
                                        className="w-10 h-10 rounded-xl bg-white/10 text-white flex items-center justify-center font-bold hover:bg-white/20 transition-colors"
                                    >
                                        +
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-2 text-left">
                                <label className="block text-sm font-bold text-gold-200 uppercase tracking-widest pl-1">
                                    {t.rsvp.dietary}
                                </label>
                                <textarea
                                    value={formData.dietary}
                                    onChange={(e) => setFormData({ ...formData, dietary: e.target.value })}
                                    className="w-full px-6 py-4 rounded-2xl bg-black/20 border border-white/10 text-white placeholder-white/30 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-all h-24 resize-none"
                                    placeholder="Gluten free, allergies, etc."
                                />
                            </div>
                        </div>
                    ) : (
                        <div className="p-4 bg-white/10 rounded-2xl text-white/90 text-center text-sm italic animate-in slide-in-from-top-2 fade-in duration-300 border border-white/10">
                            {t.rsvp.declineMessage}
                        </div>
                    )}

                    {/* Submit Button */}
                    <button
                        type="submit"
                        disabled={status === "submitting"}
                        className="w-full py-5 bg-gradient-to-r from-gold-400 to-gold-600 text-emerald-950 rounded-2xl font-black uppercase tracking-widest shadow-lg hover:shadow-gold-500/20 hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
                    >
                        {status === "submitting" ? (
                            <>
                                <Loader2 className="w-5 h-5 animate-spin" />
                                Processing...
                            </>
                        ) : t.rsvp.submit}
                    </button>

                    {status === "error" && (
                        <div className="p-3 bg-red-500/20 text-red-200 rounded-lg text-center text-sm border border-red-500/30">
                            {t.rsvp.error}
                        </div>
                    )}
                </form>
            </div>
        </div>
    );
}
