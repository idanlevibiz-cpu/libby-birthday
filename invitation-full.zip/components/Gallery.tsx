"use client";

import { useState, useEffect } from "react";
import { useLanguage } from "@/lib/i18n";
import { Camera, Loader2, Sparkles } from "lucide-react";
import Image from "next/image";

export function Gallery() {
    const { t, lang } = useLanguage();
    const [images, setImages] = useState<string[]>([]);
    const [uploading, setUploading] = useState(false);

    const fetchImages = async () => {
        try {
            const res = await fetch("/api/gallery");
            const data = await res.json();
            setImages(data.images);
        } catch (e) {
            console.error(e);
        }
    };

    useEffect(() => {
        fetchImages();
    }, []);

    const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files || e.target.files.length === 0) return;

        setUploading(true);
        const file = e.target.files[0];
        const formData = new FormData();
        formData.append("file", file);

        try {
            const res = await fetch("/api/upload", {
                method: "POST",
                body: formData,
            });
            if (res.ok) {
                await fetchImages();
            }
        } catch (e) {
            console.error("Upload failed", e);
        } finally {
            setUploading(false);
        }
    };

    return (
        <div className="w-full">
            <div className="text-center space-y-4 mb-8">
                <div className="flex justify-center">
                    <Sparkles className="w-8 h-8 text-gold-400 animate-pulse" />
                </div>
                <h2 className="font-serif text-3xl text-white drop-shadow-md">{t.gallery.title}</h2>
                <p className="font-sans text-white/70 text-sm max-w-xs mx-auto">
                    {lang === 'en' ? "Capture the fun! Upload your photos to the live gallery." : "¡Captura la diversión! Sube tus fotos a la galería."}
                </p>

                <label className="cursor-pointer inline-block mt-4">
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleUpload}
                        className="hidden"
                        disabled={uploading}
                    />
                    <div className="flex items-center gap-2 px-8 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/30 rounded-full font-bold text-sm transition-all shadow-lg backdrop-blur-sm">
                        {uploading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Camera className="w-4 h-4" />
                        )}
                        {t.gallery.upload}
                    </div>
                </label>
            </div>

            <div className="grid grid-cols-3 gap-3">
                {images.length === 0 && (
                    <div className="col-span-full py-12 text-center text-white/30 italic text-sm border-2 border-dashed border-white/10 rounded-2xl">
                        No photos yet
                    </div>
                )}
                {images.map((img, i) => (
                    <div key={i} className="aspect-square relative rounded-xl overflow-hidden bg-black/20 animate-in zoom-in duration-500 border border-white/10">
                        <Image
                            src={img}
                            alt={`Gallery ${i}`}
                            fill
                            className="object-cover hover:scale-110 transition-transform duration-500"
                        />
                    </div>
                ))}
            </div>
        </div>
    );
}
