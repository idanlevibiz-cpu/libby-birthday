import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function GET() {
    try {
        const uploadsDir = path.join(process.cwd(), "public", "uploads");

        if (!fs.existsSync(uploadsDir)) {
            return NextResponse.json({ images: [] });
        }

        const files = fs.readdirSync(uploadsDir);

        // Filter for images and map to URLs
        const images = files
            .filter(file => /\.(jpg|jpeg|png|gif|webp)$/i.test(file))
            .map(file => ({
                url: `/uploads/${file}`,
                timestamp: parseInt(file.split("-")[0]) || 0,
            }))
            .sort((a, b) => b.timestamp - a.timestamp) // Newest first
            .map(img => img.url);

        return NextResponse.json({ images });
    } catch (error) {
        console.error("Gallery Error:", error);
        return NextResponse.json({ images: [] });
    }
}
