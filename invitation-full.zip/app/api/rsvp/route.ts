import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function POST(request: Request) {
    try {
        const data = await request.json();

        // Basic validation
        if (!data.name || !data.attendance) {
            return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
        }

        const dataDir = path.join(process.cwd(), "data");
        const filePath = path.join(dataDir, "rsvps.json");

        // Ensure directory exists (redundant if mkdir run, but good practice)
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }

        // Read existing data
        let rsvps = [];
        if (fs.existsSync(filePath)) {
            const fileContent = fs.readFileSync(filePath, "utf-8");
            try {
                rsvps = JSON.parse(fileContent);
            } catch (e) {
                console.error("Error parsing existing RSVPs", e);
            }
        }

        // Add new RSVP
        const newRsvp = {
            id: Date.now().toString(),
            submittedAt: new Date().toISOString(),
            ...data,
        };
        rsvps.push(newRsvp);

        // Save
        fs.writeFileSync(filePath, JSON.stringify(rsvps, null, 2));

        // Send email notification (mock)
        console.log(`[EMAIL SENT] To: rsvp.noam@epicevents.ai | Subject: New RSVP from ${data.name} | Status: ${data.attendance}`);

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("RSVP Error:", error);
        return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
    }
}
