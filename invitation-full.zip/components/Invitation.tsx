"use client";

import { useLanguage } from "@/lib/i18n";
import { motion } from "framer-motion";
import { Calendar, Clock, MapPin, Trophy, PartyPopper } from "lucide-react";
import { cn } from "@/lib/utils";
import { Gifts } from "./Gifts";
import { Rsvp } from "./Rsvp";
import { Gallery } from "./Gallery";

export function Invitation() {
    const { t } = useLanguage();

    return (
        <div className="relative min-h-screen w-full pb-20 overflow-x-hidden font-sans">

            {/* FIXED BACKGROUND IMAGE */}
            <div className="fixed inset-0 z-0">
                <img
                    src="/hero-soccer.jpg"
                    alt="Background"
                    className="w-full h-full object-cover"
                />
                {/* Dark overlay for readability */}
                <div className="absolute inset-0 bg-emerald-950/60 backdrop-blur-[2px]" />
            </div>

            <div className="relative z-10 container mx-auto px-4 pt-12 flex flex-col items-center gap-10 max-w-2xl text-center">

                {/* HEADER CARD - Glassmorphism */}
                <motion.div
                    initial={{ opacity: 0, y: 30, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.8 }}
                    className="bg-white/10 backdrop-blur-xl p-8 md:p-10 rounded-[40px] shadow-[0_8px_32px_0_rgba(0,0,0,0.36)] border border-white/20 text-white w-full relative overflow-hidden group"
                >
                    {/* subtle shine effect */}
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

                    {/* Icon */}
                    <div className="w-16 h-16 bg-gradient-to-br from-gold-300 to-gold-600 rounded-full flex items-center justify-center mx-auto text-emerald-950 shadow-lg mb-6 animate-pulse">
                        <Trophy className="w-8 h-8" />
                    </div>

                    <h1 className="font-serif text-4xl md:text-6xl text-gold-300 drop-shadow-md leading-tight mb-4">
                        {t.eventInfo.title}
                    </h1>

                    <div className="w-24 h-1 bg-gradient-to-r from-transparent via-gold-400 to-transparent mx-auto rounded-full mb-6" />

                    <p className="text-lg md:text-xl text-cream-50 italic leading-relaxed whitespace-pre-line drop-shadow-sm">
                        {t.eventInfo.welcomeMsg}
                    </p>

                    {/* Event Details */}
                    <div className="grid gap-4 py-8 mt-4 border-t border-white/10">
                        <div className="flex items-center justify-center gap-3 text-lg font-bold text-white tracking-wide">
                            <Calendar className="w-5 h-5 text-gold-400" />
                            <span>{t.eventInfo.date}</span>
                        </div>
                        <div className="flex items-center justify-center gap-3 text-lg font-bold text-white tracking-wide">
                            <Clock className="w-5 h-5 text-gold-400" />
                            <span>{t.eventInfo.time}</span>
                        </div>
                        <div className="flex items-center justify-center gap-3 text-cream-100 whitespace-pre-line text-base">
                            <MapPin className="w-5 h-5 text-gold-400 flex-shrink-0" />
                            <span>{t.eventInfo.location}</span>
                        </div>
                    </div>

                    {/* Map Buttons */}
                    <div className="flex flex-col sm:flex-row gap-4 w-full pt-2">
                        <a
                            href="https://waze.com/ul/hde3b9v7z2"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 py-4 bg-emerald-600/80 hover:bg-emerald-500 text-white rounded-2xl font-bold uppercase tracking-widest text-sm shadow-lg transition-all hover:scale-[1.02] border border-emerald-400/30 backdrop-blur-sm"
                        >
                            Waze
                        </a>
                        <a
                            href="https://maps.app.goo.gl/random123"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 py-4 bg-blue-600/80 hover:bg-blue-500 text-white rounded-2xl font-bold uppercase tracking-widest text-sm shadow-lg transition-all hover:scale-[1.02] border border-blue-400/30 backdrop-blur-sm"
                        >
                            Google Maps
                        </a>
                    </div>
                </motion.div>

                {/* SECTIONS */}
                <div className="w-full space-y-10">

                    {/* RSVP */}
                    <Rsvp />

                    {/* Gifts */}
                    <Gifts />

                    {/* Gallery */}
                    <div className="bg-black/30 backdrop-blur-md p-6 md:p-8 rounded-[40px] border border-white/10 shadow-2xl relative overflow-hidden">
                        <div className="relative z-10">
                            <Gallery />
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}
